from tensorflow.keras import layers
from tensorflow.keras.datasets import cifar10